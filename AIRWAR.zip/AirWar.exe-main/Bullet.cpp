#include "Bullet.h"
#include <QTimer>
#include <QDebug>
#include <QGraphicsScene>
#include <QList>
#include "Enemy.h"
#include "Score.h"
#include "Game.h"

extern Game * game;

Bullet::Bullet(QGraphicsItem *parent): QObject(), QGraphicsPixmapItem(parent){
    setPixmap(QPixmap(":/images/bullet2.png"));


     QTimer * timer = new QTimer();
     connect(timer, SIGNAL(timeout()), this, SLOT(move()));

     timer->start(50); // set the timer time to 50 ms
}

void Bullet::move() {
    /* Before moving the bullet*/
    QList<QGraphicsItem *> colliding_item = collidingItems();

    for(int i = 0; i < colliding_item.size(); i++) {
        if(typeid(*(colliding_item[i])) == typeid(Enemy)) {
            game->score->increase();
            // Remove both the enemy & bullet
            scene()->removeItem(colliding_item[i]); // remove the enemy
            scene()->removeItem(this); // remove the bullet
            delete colliding_item[i];
            delete this;
            return ;
        }
    }
    // move the bullet up
    setPos(x(), y() - 10);

    if(pos().y() < 0) {
        scene()->removeItem(this);
        delete this;
    }
}

